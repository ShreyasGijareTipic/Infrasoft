<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your OTP Code</title>
</head>
<body>
    <p>Hello,</p>
    <p>Your OTP code is: <strong>{{ $otpCode }}</strong></p>
    <p>This code will expire in 10 minutes. If you did not request this, please ignore this email.</p>
    <p>Thank you!</p>
</body>
</html>
