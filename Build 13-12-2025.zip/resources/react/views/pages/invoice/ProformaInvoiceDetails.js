import React, { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  CCard,
  CCardBody,
  CCardHeader,
  CButton,
  CRow,
  CCol,
  CSpinner,
  CBadge,
  CAlert,
  CFormSelect,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilArrowLeft, cilPencil, cilCreditCard, cilHistory, cilPrint } from '@coreui/icons'
import { getAPICall } from '../../../util/api'
import { useToast } from '../../common/toast/ToastContext'
import { generateProformaInvoicePDF } from './ProformaInvoicePDF'
import RecordPaymentModal from './RecordPaymentModal'

const ProformaInvoiceDetails = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const { showToast } = useToast()

  const [loading, setLoading] = useState(true)
  const [proformaInvoice, setProformaInvoice] = useState(null)
  const [selectedLang, setSelectedLang] = useState('english')
  const [showPaymentModal, setShowPaymentModal] = useState(false)

  useEffect(() => {
    fetchProformaInvoice()
  }, [id])

  const fetchProformaInvoice = async () => {
    try {
      setLoading(true)
      const response = await getAPICall(`/api/proforma-invoices/${id}`)

      if (response.success) {
        setProformaInvoice(response.data)
      } else {
        showToast('danger', 'Failed to fetch proforma invoice')
      }
    } catch (error) {
      console.error('Error fetching proforma invoice:', error)
      showToast('danger', 'Error fetching proforma invoice details')
    } finally {
      setLoading(false)
    }
  }

  const handleRecordPayment = () => {
    setShowPaymentModal(true)
  }

  const handlePaymentRecorded = () => {
    fetchProformaInvoice()
    setShowPaymentModal(false)
  }

  const handleDownload = async () => {
    if (!proformaInvoice) return

    await generateProformaInvoicePDF(
      proformaInvoice,
      selectedLang,
      'save'
    )
  }

  const handlePrint = () => {
    window.print()
  }

  const getPaymentStatusBadge = (status) => {
    const badges = {
      pending: { color: 'danger', text: 'Pending' },
      partial: { color: 'warning', text: 'Partially Paid' },
      paid: { color: 'success', text: 'Fully Paid' },
    }
    return badges[status] || badges.pending
  }

  // Check if any item has GST data
  const hasGSTData = () => {
    if (!proformaInvoice || !proformaInvoice.details) return false
    return proformaInvoice.details.some(item =>
      (item.gst_percent && item.gst_percent > 0) ||
      (item.cgst_amount && item.cgst_amount > 0) ||
      (item.sgst_amount && item.sgst_amount > 0)
    )
  }

  // Calculate totals from items
  const calculateDisplayTotals = () => {
    if (!proformaInvoice || !proformaInvoice.details) {
      return {
        subtotalWithoutGST: 0,
        totalCGST: 0,
        totalSGST: 0,
        totalGST: 0,
        grandTotalWithGST: 0
      }
    }

    const subtotalWithoutGST = proformaInvoice.details.reduce((sum, item) => sum + (item.qty * item.price), 0)
    const totalCGST = proformaInvoice.details.reduce((sum, item) => sum + (item.cgst_amount || 0), 0)
    const totalSGST = proformaInvoice.details.reduce((sum, item) => sum + (item.sgst_amount || 0), 0)
    const totalGST = totalCGST + totalSGST
    const grandTotalWithGST = proformaInvoice.details.reduce((sum, item) => sum + (item.total_price || 0), 0)

    return {
      subtotalWithoutGST,
      totalCGST,
      totalSGST,
      totalGST,
      grandTotalWithGST
    }
  }

  if (loading) {
    return (
      <div className="text-center py-5">
        <CSpinner color="primary" />
        <div className="mt-2">Loading proforma invoice...</div>
      </div>
    )
  }

  if (!proformaInvoice) {
    return (
      <CAlert color="warning">
        Proforma invoice not found
      </CAlert>
    )
  }

  const statusBadge = getPaymentStatusBadge(proformaInvoice.payment_status)
  const showGST = hasGSTData()
  const displayTotals = calculateDisplayTotals()

  return (
    <>
      <CCard>
        <CCardHeader>
          <div className="d-flex justify-content-between align-items-center">
            <h5>Proforma Invoice {proformaInvoice.proforma_invoice_number}</h5>
            <div>
              <CBadge color={statusBadge.color} className="me-2">
                {statusBadge.text}
              </CBadge>
              <CButton
                color="secondary"
                size="sm"
                onClick={() => navigate('/invoiceTable')}
              >
                <CIcon icon={cilArrowLeft} className="me-1" />
                Back
              </CButton>
            </div>
          </div>
        </CCardHeader>
        <CCardBody>
          {/* Invoice Info */}
          <div className="row section mb-4">
            <div className="col-md-6">
              <h6>Invoice Information</h6>
              <p><strong>Proforma Invoice #:</strong> {proformaInvoice.proforma_invoice_number}</p>
              {proformaInvoice.tally_invoice_number && (
                <p><strong>Tally Invoice #:</strong> {proformaInvoice.tally_invoice_number}</p>
              )}
              <p><strong>Invoice Date:</strong> {new Date(proformaInvoice.invoice_date).toLocaleDateString()}</p>
              {proformaInvoice.delivery_date && (
                <p><strong>Delivery Date:</strong> {new Date(proformaInvoice.delivery_date).toLocaleDateString()}</p>
              )}
            </div>
            <div className="col-md-6">
              <h6>Work Order & Project Information</h6>
              <p><strong>Work Order #:</strong> {proformaInvoice.work_order?.invoice_number}</p>
              <p><strong>Project:</strong> {proformaInvoice.project?.project_name}</p>
              <p><strong>Customer:</strong> {proformaInvoice.customer?.name}</p>
              <p><strong>Location:</strong> {proformaInvoice.customer?.address}</p>
              <p><strong>Mobile:</strong> {proformaInvoice.customer?.mobile}</p>
            </div>
          </div>

          {/* Work Details Table */}
          <div className="row section mb-4">
            <div className="col-md-12">
              <h6>Work Details</h6>
              <table className="table table-bordered">
                <thead>
                  <tr>
                    <th>Sr. No.</th>
                    <th>Work Type</th>
                    <th>Unit</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    {showGST && <th>Base Amount</th>}
                    {showGST && <th>GST %</th>}
                    {showGST && <th>CGST</th>}
                    {showGST && <th>SGST</th>}
                    <th>Total</th>
                    <th>Remark</th>
                  </tr>
                </thead>
                <tbody>
                  {proformaInvoice.details && proformaInvoice.details.length > 0 ? (
                    proformaInvoice.details.map((item, index) => (
                      <tr key={index}>
                        <td>{index + 1}</td>
                        <td>{item.work_type}</td>
                        <td>{item.uom}</td>
                        <td>{item.qty}</td>
                        <td>₹{parseFloat(item.price).toFixed(2)}</td>
                        {showGST && <td>₹{(item.qty * item.price).toFixed(2)}</td>}
                        {showGST && <td>{item.gst_percent ? `${item.gst_percent}%` : '-'}</td>}
                        {showGST && <td>₹{(item.cgst_amount || 0).toFixed(2)}</td>}
                        {showGST && <td>₹{(item.sgst_amount || 0).toFixed(2)}</td>}
                        <td>₹{parseFloat(item.total_price).toFixed(2)}</td>
                        <td>{item.remark || '-'}</td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={showGST ? "11" : "7"} className="text-center">No work details available</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Financial Details */}
          <div className="row section mb-4">
            <div className="col-md-12">
              <h6>Financial Summary</h6>
              <table className="table table-bordered">
                <tbody>
                  <tr>
                    <td><strong>Subtotal {showGST ? '(Without GST)' : ''}:</strong></td>
                    <td className="text-end">₹{displayTotals.subtotalWithoutGST.toFixed(2)}</td>
                  </tr>
                  {showGST && (
                    <>
                      <tr>
                        <td><strong>Total CGST:</strong></td>
                        <td className="text-end">₹{displayTotals.totalCGST.toFixed(2)}</td>
                      </tr>
                      <tr>
                        <td><strong>Total SGST:</strong></td>
                        <td className="text-end">₹{displayTotals.totalSGST.toFixed(2)}</td>
                      </tr>
                      <tr>
                        <td><strong>Total GST:</strong></td>
                        <td className="text-end">₹{displayTotals.totalGST.toFixed(2)}</td>
                      </tr>
                    </>
                  )}
                  {proformaInvoice.discount > 0 && (
                    <tr>
                      <td><strong>Discount:</strong></td>
                      <td className="text-end">₹{parseFloat(proformaInvoice.discount).toFixed(2)}</td>
                    </tr>
                  )}
                  <tr className="table-primary">
                    <td><strong>Final Amount {showGST ? '(with GST)' : ''}:</strong></td>
                    <td className="text-end"><strong>₹{parseFloat(proformaInvoice.final_amount).toFixed(2)}</strong></td>
                  </tr>
                  <tr className="table-success">
                    <td><strong>Paid Amount:</strong></td>
                    <td className="text-end">₹{parseFloat(proformaInvoice.paid_amount).toFixed(2)}</td>
                  </tr>
                  <tr className="table-warning">
                    <td><strong>Pending Amount:</strong></td>
                    <td className="text-end">₹{parseFloat(proformaInvoice.pending_amount).toFixed(2)}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Notes */}
          {proformaInvoice.notes && (
            <div className="row section mb-4">
              <div className="col-md-12">
                <h6>Additional Notes</h6>
                <p>{proformaInvoice.notes}</p>
              </div>
            </div>
          )}

          {/* Terms, Payment Terms, and Notes */}
          <div className="row section mb-4">
            <div className="col-md-12">
              {/* Payment Terms */}
              {proformaInvoice.payment_terms && (
                <>
                  <h6 className="mt-3">Payment Terms</h6>
                  <ul>
                    {proformaInvoice.payment_terms
                      .split('\n')
                      .filter((line) => line.trim() !== '')
                      .map((line, index) => (
                        <li key={index}>{line}</li>
                      ))}
                  </ul>
                </>
              )}

              {/* Terms & Conditions */}
              {proformaInvoice.terms_conditions && (
                <>
                  <h6>Terms & Conditions</h6>
                  <ul>
                    {proformaInvoice.terms_conditions
                      .split('\n')
                      .filter((line) => line.trim() !== '')
                      .map((line, index) => (
                        <li key={index}>{line}</li>
                      ))}
                  </ul>
                </>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="d-flex justify-content-center flex-wrap gap-2 d-print-none">
            {proformaInvoice.pending_amount > 0 && (
              <CButton
                color="success"
                onClick={handleRecordPayment}
              >
                <CIcon icon={cilCreditCard} className="me-1" />
                Record Payment
              </CButton>
            )}

            <CButton
              color="info"
              onClick={handleDownload}
            >
              Download PDF ({selectedLang})
            </CButton>
          </div>
        </CCardBody>
      </CCard>

      {/* Payment Modal */}
      {showPaymentModal && (
        <RecordPaymentModal
          visible={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          orderData={{
            id: proformaInvoice.id,
            proforma_invoice_id: proformaInvoice.id,
            invoice_number: proformaInvoice.proforma_invoice_number,
            project_name: proformaInvoice.project?.project_name,
            finalAmount: proformaInvoice.final_amount,
            paidAmount: proformaInvoice.paid_amount,
            isProformaInvoice: true,
          }}
          onPaymentRecorded={handlePaymentRecorded}
        />
      )}
    </>
  )
}

export default ProformaInvoiceDetails