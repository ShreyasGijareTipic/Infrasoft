// Auto-generated version file
export const APP_VERSION = '1.0.38_13_12_2025';
export const BUILD_DATE = '2025-12-13T03:38:00.171Z';
export const VERSION_NUMBER = '1.0.38';
