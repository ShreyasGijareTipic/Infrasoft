<?php echo e($slot); ?>

<?php /**PATH D:\project\Deshmukh_infra\deshmukh_infra\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>