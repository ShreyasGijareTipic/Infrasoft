export const gst =18;

export const receiver_bank=[  
    { value: 'Mangesh Shitole', label: 'Mangesh Shitole' },
    { value: 'Krishna Shitole', label: 'Krishna Shitole' },
    { value: 'Deshmukh infra LLP', label: 'Deshmukh infra LLP' },
     { value: 'Amol Jagtap', label: 'Amol Jagtap' },
];

export const paymentTypes = [
    { value: 'imps', label: 'IMPS' },
    { value: 'rtgs', label: 'RTGS' },
    { value: 'upi', label: 'UPI' },
    { value: 'cash', label: 'Cash' },
    { value: 'cheque', label: 'Cheque' }
  ];

  export const workTypeDropdown = [
    {value:'Drilling',label:'Drilling'},
    {value:'Pilling',label:'Pilling'},
    {value:'DTH',label:'DTH'},
    {value:'Fencing',label:'Fencing'},
    {value:'Casting',label:'Casting'},
    {value:'Casting+Drilling',label:'Casting+Drilling'},
    {value:'Earthing',label:'Earthing'},
    {value:'Compound',label:'Compound'},
    {value:'Aligning',label:'Aligning'},
    {value:'Auger',label:'Auger'},
     {value:'Disel',label:'Disel'}, 
     {value:'Petrol',label:'Petrol'},
  ]

  export const SurveyTypeDropdown =[
    {value:'Drone',label:'Drone'},
    {value:'Topography',label:'Topography'},
    {value:'Boundary',label:'Boundary'},
    {value:'Site Survey',label:'Site Survey'},
    {value:'Progress Survey',label:'Progress Survey'}, 
    {value:'TS Machine',label:'TS Machine'},
    {value:'Survey Machine',label:'Survey Machine'},

  ]
  
