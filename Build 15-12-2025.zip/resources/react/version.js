// Auto-generated version file
export const APP_VERSION = '1.1.4_15_12_2025';
export const BUILD_DATE = '2025-12-15T12:32:34.135Z';
export const VERSION_NUMBER = '1.1.4';
